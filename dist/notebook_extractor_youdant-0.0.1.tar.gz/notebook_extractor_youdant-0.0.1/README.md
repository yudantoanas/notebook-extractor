# Notebook Extractor

A tool to extract code from Jupyter Notebook and generate python script file